package com.infy.demo.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.demo.model.Product;
import com.infy.demo.repository.ProductRepository;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepository repo;

	@Override
	public Product addProduct(Product product) {

		return repo.save(product);
	}

	@Override
	public Product updateProduct(Product product) {

		return repo.save(product);
	}

	@Override
	public String deleteProduct(int productId) {
		repo.deleteById(productId);
		return "deleted successfully....";
	}

	@Override
	public Optional<Product> getProduct(int productId) {

		return repo.findById(productId);
	}

	@Override
	public List<Product> getAllProducts() {

		return repo.findAll();//select e from product e
	}

	@Override
	public List<Product> getAllProductsByName(String productName) {

		return repo.findByProductName(productName);//DSL
	}

	@Override
	public List<Product> getAllProductsByCategory(String productCategory) {

		return repo.findByProductCategory(productCategory);
	}

	@Override
	public List<Product> getAllProductsByBetweenPrices(int iPrice, int price) {

		return repo.findByProductPriceBetween(iPrice, price);
	}

	@Override
	public List<Product> getAllProductsLike(String word) {

		return repo.findByProductNameContaining(word);
	}

}
