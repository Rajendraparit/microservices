package com.infy.jpademo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("sleeping");
		EntityManager entityManager = factory.createEntityManager();

		// crud-->insert-->persist(),update-->merge(),delete-->remove(),get-->find() ORM
		Employee emp = new Employee(12, "suresh", "banglore", 220000);
		entityManager.getTransaction().begin();
		entityManager.persist(emp);// dml

		entityManager.getTransaction().commit();
	}

}
