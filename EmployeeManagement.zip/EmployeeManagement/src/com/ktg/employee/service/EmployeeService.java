package com.ktg.employee.service;

import java.util.Set;

import com.ktg.employee.model.Employee;

public interface EmployeeService {
	Employee addEmployee(Employee emp);

	Employee updateEmployee(Employee emp);

	String deleteEmployee(int empId);

	Employee getEmployee(int empId);

	Set<Employee> getAllEmployees();
}
