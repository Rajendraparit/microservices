package com.ktg.employee.service;

import java.util.Set;

import com.ktg.employee.model.Employee;
import com.ktg.employee.repository.EmployeeRepository;
import com.ktg.employee.repository.EmployeeRepositoryImpl;

public class EmployeeServiceImpl implements EmployeeService {
	EmployeeRepository repo=new EmployeeRepositoryImpl();
	@Override
	public Employee addEmployee(Employee emp) {
		
		return repo.addEmployee(emp);
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		
		return repo.updateEmployee(emp);
	}

	@Override
	public String deleteEmployee(int empId) {
		
		return repo.deleteEmployee(empId);
	}

	@Override
	public Employee getEmployee(int empId) {
		
		return repo.getEmployee(empId);
	}

	@Override
	public Set<Employee> getAllEmployees() {
		
		return repo.getAllEmployees();
	}

}
