package com.ktg.employee.repository;

import java.util.Set;

import com.ktg.employee.model.Employee;

public interface EmployeeRepository {
	Employee addEmployee(Employee emp);

	Employee updateEmployee(Employee emp);

	String deleteEmployee(int empId);

	Employee getEmployee(int empId);

	Set<Employee> getAllEmployees();
}
