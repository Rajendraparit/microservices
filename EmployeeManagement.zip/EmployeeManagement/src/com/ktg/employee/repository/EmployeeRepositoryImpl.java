package com.ktg.employee.repository;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.ktg.employee.model.Employee;

public class EmployeeRepositoryImpl implements EmployeeRepository {

	Map<Integer, Employee> employees = new HashMap<>();

	@Override
	public Employee addEmployee(Employee emp) {// 111 sandeep
		employees.put(emp.getEmpId(), emp);
		return employees.get(emp.getEmpId());
	}

	@Override
	public Employee updateEmployee(Employee emp) {// 111 pranay
		employees.put(emp.getEmpId(), emp);
		return employees.get(emp.getEmpId());
	}

	@Override
	public String deleteEmployee(int empId) {
		employees.remove(empId);
		return "deleted Successfully" + empId;
	}

	@Override
	public Employee getEmployee(int empId) {

		return employees.get(empId);
	}

	@Override
	public Set<Employee> getAllEmployees() {
		Set<Entry<Integer, Employee>> emps = employees.entrySet();// will convert map to set
		Iterator<Entry<Integer, Employee>> itr = emps.iterator();//from entry getting one by one and adding to set using iterator
		Set<Employee> finalResult=new HashSet<>();
		while(itr.hasNext())//fetching all employees one by one and adding it to set
		{
			Entry<Integer,Employee> emp=itr.next();
			finalResult.add(emp.getValue());
		}
		return finalResult;
	}

}
