package com.ktg.employee.ui;

import java.util.Scanner;
import java.util.Set;

import com.ktg.employee.model.Employee;
import com.ktg.employee.service.EmployeeService;
import com.ktg.employee.service.EmployeeServiceImpl;

public class EmployeeManagementApp {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("**********Employee Management Application********");
		EmployeeService service= new EmployeeServiceImpl();
			int empId=0;
			String empName=null;
			String empAddress=null;
			int empSalary=0;
		//	long empContact=0;
		while (true) {
			System.out.println("1.Add Employee");
			System.out.println("2.Update Employee");
			System.out.println("3.Delete Employee");
			System.out.println("4.Fetch Employee");
			System.out.println("5.Fetch All Employees");
			int option = scan.nextInt();
			switch (option) {
			case 1:
				System.out.println("Enter Employee Info To ADD");
				System.out.println("Enter Employee Id:");
				 empId = scan.nextInt();
				System.out.println("Enter Employee Name:");
				 empName = scan.next();
				System.out.println("Enter Employee Address:");
				 empAddress = scan.next();
				System.out.println("Enter Employee Salary:");
				 empSalary = scan.nextInt();
					//System.out.println("Enter Employee COntact:");
					// empContact = scan.nextLong();//7,8,9 10
				Employee employee = new Employee(empId, empName, empAddress, empSalary);
				Employee result=service.addEmployee(employee);
				System.out.println(result);
				break;
			case 2:
				System.out.println("Enter Employee Info To Update");
				System.out.println("Enter Employee Id:");
				 empId = scan.nextInt();
				System.out.println("Enter Employee Name:");
				 empName = scan.next();
				System.out.println("Enter Employee Address:");
				 empAddress = scan.next();
				System.out.println("Enter Employee Salary:");
				 empSalary = scan.nextInt();

				Employee employee1 = new Employee(empId, empName, empAddress, empSalary);
				Employee result1=service.updateEmployee(employee1);
				System.out.println("Updated Employee Info:");
				System.out.println(result1);
				break;
			case 3:
				System.out.println("Enter Employee Info To Delete");
				System.out.println("Enter Employee Id:");
				 empId = scan.nextInt();
				String result2= service.deleteEmployee(empId);
				System.out.println(result2);
				break;
			case 4:
				System.out.println("Enter Employee Info To Fetch");
				System.out.println("Enter Employee Id:");
				 empId = scan.nextInt();
				Employee result3= service.getEmployee(empId);
				System.out.println(result3);
				break;
			case 5:
				Set<Employee> set=service.getAllEmployees();
				set.stream().forEach(System.out::println);
				break;
			}

		}

	}

}
