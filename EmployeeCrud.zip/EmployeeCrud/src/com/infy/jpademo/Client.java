package com.infy.jpademo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("sleeping");
		EntityManager entityManager = factory.createEntityManager();

		// crud-->insert-->persist(),update-->merge(),delete-->remove(),get-->find() ORM
		Employee emp = new Employee(123, "naresh", "delhi", 20000);
		entityManager.getTransaction().begin();
		entityManager.persist(emp);// dml

		Employee emp1 = entityManager.find(Employee.class, 123);

		System.out.println(emp1);

		emp1.setEmpSal(10000);
		emp1.setEmpAdd("USA");

		entityManager.merge(emp1);
		System.out.println(emp1);

		entityManager.remove(emp1);

		entityManager.getTransaction().commit();
	}

}
