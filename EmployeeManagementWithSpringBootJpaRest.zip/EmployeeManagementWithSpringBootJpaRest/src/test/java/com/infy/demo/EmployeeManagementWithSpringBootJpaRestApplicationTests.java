package com.infy.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManagementWithSpringBootJpaRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
