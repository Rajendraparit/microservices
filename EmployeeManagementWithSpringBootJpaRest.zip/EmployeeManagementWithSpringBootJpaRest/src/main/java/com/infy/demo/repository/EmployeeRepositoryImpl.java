package com.infy.demo.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.infy.demo.model.Employee;

@Repository
public class EmployeeRepositoryImpl implements EmployeeRepository {
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public String addEmployee(Employee employee) {
		entityManager.persist(employee);
		return "Employee Saved Successfully";
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		return entityManager.merge(employee);
	}

	@Override
	public String deleteEmployee(int employeeId) {
		entityManager.remove(entityManager.find(Employee.class, employeeId));
		return "Employee removed Successfully";
	}

	@Override
	public Employee getEmployee(int employeeId) {

		return entityManager.find(Employee.class, employeeId);
	}

	@Override
	public List<Employee> getAllEmployee() {
		TypedQuery<Employee> result = entityManager.createQuery("select e from Employee e", Employee.class);
		return result.getResultList();
	}

}
