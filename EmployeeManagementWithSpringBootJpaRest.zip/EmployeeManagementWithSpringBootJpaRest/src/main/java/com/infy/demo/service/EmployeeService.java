package com.infy.demo.service;

import java.util.List;

import com.infy.demo.model.Employee;

public interface EmployeeService {
	public String addEmployee(Employee employee);

	public Employee updateEmployee(Employee employee);

	public String deleteEmployee(int employeeId);

	public Employee getEmployee(int employeeId);

	public List<Employee> getAllEmployee();
}
