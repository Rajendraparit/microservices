package com.infy.demo.repository;

import java.util.List;

import com.infy.demo.model.Employee;

public interface EmployeeRepository {
	public String addEmployee(Employee employee);

	public Employee updateEmployee(Employee employee);

	public String deleteEmployee(int employeeId);

	public Employee getEmployee(int employeeId);

	public List<Employee> getAllEmployee();
}
