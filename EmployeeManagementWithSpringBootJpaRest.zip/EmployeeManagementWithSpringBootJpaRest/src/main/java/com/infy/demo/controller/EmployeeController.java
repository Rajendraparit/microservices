package com.infy.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.demo.model.Employee;
import com.infy.demo.service.EmployeeService;

@RestController // @Controller+@ResponseBody
@RequestMapping("/employee")
public class EmployeeController {
	@Autowired
	EmployeeService service;

	/*
	 * { "empId":123, "empName":"titash", "empSal":90000, "empAdd":"mumbai" }
	 */
	// http://localhost:8586/employee/insertEmployee
	@PostMapping("/insertEmployee") // json
	public String addEmployee(@RequestBody Employee employee) {
		return service.addEmployee(employee);
	}

	// http://localhost:8586/employee/updateEmployee
	@PutMapping("/updateEmployee") // json
	public Employee updateEmployee(@RequestBody Employee employee) {
		return service.updateEmployee(employee);
	}

	// http://localhost:8586/employee/deleteEmployee/123
	@DeleteMapping("/deleteEmployee/{id}")
	public String deleteEmployee(@PathVariable("id") int employeeId) {
		return service.deleteEmployee(employeeId);
	}

	// http://localhost:8586/employee/getEmployee/123
	@GetMapping("/getEmployee/{id}")
	public Employee getEmployee(@PathVariable("id") int employeeId) {
		return service.getEmployee(employeeId);
	}

	// http://localhost:8586/employee/getAllEmployee
	@GetMapping("/getAllEmployee")
	public List<Employee> getAllEmployee() {
		return service.getAllEmployee();
	}
}
