package com.infy.demo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.demo.model.Employee;
import com.infy.demo.repository.EmployeeRepository;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	EmployeeRepository repository;

	@Override
	public String addEmployee(Employee employee) {

		return repository.addEmployee(employee);
	}

	@Override
	public Employee updateEmployee(Employee employee) {

		return repository.updateEmployee(employee);
	}

	@Override
	public String deleteEmployee(int employeeId) {

		return repository.deleteEmployee(employeeId);
	}

	@Override
	public Employee getEmployee(int employeeId) {

		return repository.getEmployee(employeeId);
	}

	@Override
	public List<Employee> getAllEmployee() {

		return repository.getAllEmployee();
	}

}
