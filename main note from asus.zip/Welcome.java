class Welcome				// PI user understandable lang
{
		//all the keywords in java must be in lower case 
		//all the class names in java must be pascal case 
	  // all the method/variable names in java must camel case 

			static int age=23;//global var and can be accessed any where inside class
					float salary=23.45f; //instance 4 bytes 
			public  static void main(String args[])
			{
					float salary=23.78f;//local var and can be accessed only  with in the method 
					System.out.println(salary);
					System.out.println(Welcome.age);//accessing static variable using classname 
					Welcome wel=new Welcome();		//memory creation for welcome class instance properties
					System.out.println(wel.salary);//accessing instance variable using objref 
					Welcome wel1=new Welcome();
				}
}