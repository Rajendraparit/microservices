package com.info.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;


@ComponentScan("com.info.springcore")//@ComponentScans
@Configuration
public class Client {
	public static void main(String[] args) {

		// container -->BeanFactory,ApplicationContext
		// complete object life cycle will be managed by container
		// creation object,wiring the dependencies,configuration,destroy

//		Resource resource = new ClassPathResource("springconfig.xml");<bean id="employee" class="Employee" scope="prototype" autowire="">
//		BeanFactory factory = new XmlBeanFactory(resource);//lazy 	ApplicationContext		container
		// ClassPathXmlApplicationContext,autowire-->Autowired  ,scope-->singleton,prototype

		ApplicationContext context = new AnnotationConfigApplicationContext(Client.class);

		Employee emp = context.getBean("employee", Employee.class);
		System.out.println(emp);
		
		Employee emp1 = context.getBean("employee", Employee.class);
		System.out.println(emp1);
		
		//spring config (xml)
		
		//spring has given annotations like @Component/@Service/@Repository,@scope,@Autowired,@Configuration,@ComponentScan
		// for user defined classes but not predefined classes(java config)
		
		//predefined classes (java config)@Bean
		
		
		
		
		// @Configuration

	}
}
