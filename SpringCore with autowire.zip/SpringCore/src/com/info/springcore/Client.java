package com.info.springcore;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Client {
	public static void main(String[] args) {

		// container -->BeanFactory,ApplicationContext
		// complete object life cycle will be managed by container
		// creation object,wiring the dependencies,configuration,destroy
		
		Resource resource = new ClassPathResource("springconfig.xml");
		BeanFactory factory = new XmlBeanFactory(resource);//lazy
		Employee emp = factory.getBean("employee", Employee.class);
		System.out.println(emp);

	}
}
