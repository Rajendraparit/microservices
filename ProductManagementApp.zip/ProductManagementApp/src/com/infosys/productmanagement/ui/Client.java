package com.infosys.productmanagement.ui;

import java.util.Scanner;
import java.util.Set;

import com.infosys.productmanagement.dto.Product;
import com.infosys.productmanagement.service.ProductService;
import com.infosys.productmanagement.service.ProductServiceI;

public class Client {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.println("**********Product Management Application********");
		ProductService service = new ProductServiceI();
		int productId = 0;
		String productName = null;
		float productPrice = 0;
		int quantity = 0;

		while (true) {
			System.out.println("1.add Product");
			System.out.println("2.Update Product");
			System.out.println("3.Delete Product");
			System.out.println("4.Fetch Product");
			System.out.println("5.Fetch All Products");
			int option = scan.nextInt();
			switch (option) {
			case 1:
				System.out.println("Enter Product Info To ADD");
				System.out.println("Enter Product Id:");
				productId = scan.nextInt();
				System.out.println("Enter Product Name:");
				productName = scan.next();
				System.out.println("Enter Product price:");
				productPrice = scan.nextFloat();
				System.out.println("Enter Product quantity:");
				quantity = scan.nextInt();
				Product product = new Product(productId, productName, productPrice, quantity);
				String result = service.addProduct(product);
				System.out.println(result);
				break;
			case 2:
				System.out.println("Enter Product Info To Update");
				System.out.println("Enter Product Id:");
				productId = scan.nextInt();
				System.out.println("Enter Product Name:");
				productName = scan.next();
				System.out.println("Enter Product price:");
				productPrice = scan.nextFloat();
				System.out.println("Enter Product quantity:");
				quantity = scan.nextInt();

				Product Product1 = new Product(productId, productName, productPrice, quantity);
				Product result1 = service.updateProduct(Product1);
				System.out.println("Updated Product Info:");
				System.out.println(result1);
				break;
			case 3:
				System.out.println("Enter Product Info To Delete");
				System.out.println("Enter Product Id:");
				productId = scan.nextInt();
				String result2 = service.deleteProduct(productId);
				System.out.println(result2);
				break;
			case 4:
				System.out.println("Enter Product Info To Fetch");
				System.out.println("Enter Product Id:");
				productId = scan.nextInt();
				Product result3 = service.getProduct(productId);
				System.out.println(result3);
				break;
			case 5:
				Set<Product> set = service.getAllProducts();
				set.stream().forEach(System.out::println);
				break;
			}

		}

	}
}
