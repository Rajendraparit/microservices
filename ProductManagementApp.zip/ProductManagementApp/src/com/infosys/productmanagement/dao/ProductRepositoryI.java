package com.infosys.productmanagement.dao;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

import com.infosys.productmanagement.dto.Product;

//ctrl+shift+O
public class ProductRepositoryI implements ProductRepository {

	HashMap<Integer, Product> products = new HashMap<Integer, Product>();

	@Override
	public String addProduct(Product product) {
		products.put(product.getProductId(), product);
		if (products.size() > 0) {
			return "product added successfully";
		} else {
			return "adding product failed ...";
		}
	}

	@Override
	public Product updateProduct(Product product) {
		products.put(product.getProductId(), product);
		return products.get(product.getProductId());
	}

	@Override
	public String deleteProduct(int productId) {
		Product product = products.remove(productId);
		if (product != null)
			return "product deleted successfully";
		else
			return "product deletion failed .....";
	}

	@Override
	public Product getProduct(int productId) {
		
		return products.get(productId);
	}

	@Override
	public Set<Product> getAllProducts() {
	Set<Entry<Integer,Product>> products1=	products.entrySet();
	Set<Product> result=new HashSet<Product>();
	Iterator<Entry<Integer,Product>> itr=	products1.iterator();
	while(itr.hasNext())
	{
		Entry<Integer,Product> entry=itr.next();
		result.add(entry.getValue());
	}
		return result;
	}

}
