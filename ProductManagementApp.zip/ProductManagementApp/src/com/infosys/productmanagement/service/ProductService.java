package com.infosys.productmanagement.service;

import java.util.Set;

import com.infosys.productmanagement.dto.Product;

public interface ProductService {

	public String addProduct(Product product);

	public Product updateProduct(Product product);

	public String deleteProduct(int productId);

	public Product getProduct(int productId);

	public Set<Product> getAllProducts();

}
