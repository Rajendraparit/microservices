package com.infosys.productmanagement.service;

import java.util.Set;

import com.infosys.productmanagement.dao.ProductRepository;
import com.infosys.productmanagement.dao.ProductRepositoryI;
import com.infosys.productmanagement.dto.Product;

public class ProductServiceI implements ProductService {
	ProductRepository dao = new ProductRepositoryI();

	@Override
	public String addProduct(Product product) {

		return dao.addProduct(product);
	}

	@Override
	public Product updateProduct(Product product) {

		return dao.updateProduct(product);
	}

	@Override
	public String deleteProduct(int productId) {

		return dao.deleteProduct(productId);
	}

	@Override
	public Product getProduct(int productId) {

		return dao.getProduct(productId);
	}

	@Override
	public Set<Product> getAllProducts() {

		return dao.getAllProducts();
	}

}
