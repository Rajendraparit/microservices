package com.infy.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductManagementCrudUSingSprigDataJpaHibernateApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductManagementCrudUSingSprigDataJpaHibernateApplication.class, args);
	}

}
