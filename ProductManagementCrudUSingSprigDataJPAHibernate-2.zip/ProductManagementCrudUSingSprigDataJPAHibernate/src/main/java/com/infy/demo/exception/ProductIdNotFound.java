package com.infy.demo.exception;

public class ProductIdNotFound extends RuntimeException {

	public ProductIdNotFound(String message) {
	super(message);
	}
	
}
