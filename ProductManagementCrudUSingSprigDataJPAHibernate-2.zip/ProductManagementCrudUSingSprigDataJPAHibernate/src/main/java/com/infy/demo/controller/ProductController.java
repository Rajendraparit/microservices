package com.infy.demo.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.demo.exception.ProductIdNotFound;
import com.infy.demo.model.Product;
import com.infy.demo.service.ProductService;

@RestController
@RequestMapping("/product")
public class ProductController {
	@Autowired
	ProductService service;

	// http://localhost:7878/product/addProduct
	/*
	 * { "productId":111, "productName":"samsung mobile", "productPrice":20000,
	 * "productCategory":"elctronics", "productQuantity":20,
	 * "productDescription":"samsungbrand", "productSoldBy":"amazon" }
	 */

	@PostMapping("/addProduct")
	public Product addProduct(@RequestBody @Valid Product product) {
		return service.addProduct(product);
	}

	@PutMapping("/updateProduct")
	public Product updateProduct(@RequestBody Product product) {
		return service.updateProduct(product);
	}

	@DeleteMapping("/deleteProduct/{pid}")
	public String deleteProduct(@PathVariable("pid") int productId) {
		return service.deleteProduct(productId);
	}

	@GetMapping("/getProduct/{pid}")
	public Product getProduct(@PathVariable("pid") int productId) {
		Optional<Product> product = service.getProduct(productId);
		
		if (product.isPresent()) {
			return product.get();
		}
		else
		{
			throw new ProductIdNotFound("Enter valid productid to get product....");
		}
	}

	@GetMapping("/getAllProducts")
	public List<Product> getAllProducts() {
		return service.getAllProducts();
	}

	@GetMapping("/getAllProductsByName/{pname}")
	public List<Product> getAllProductsByName(@PathVariable("pname") String productName) {
		return service.getAllProductsByName(productName);
	}

	@GetMapping("/getAllProductsByCategory/{category}")
	public List<Product> getAllProductsByCategory(@PathVariable("category") String category) {
		return service.getAllProductsByCategory(category);
	}

	@GetMapping("/getAllProductsBetween/{p1}/{p2}")
	public List<Product> getAllProductsBetween(@PathVariable("p1") int price, @PathVariable("p2") int price1) {
		return service.getAllProductsByBetweenPrices(price, price1);
	}

	@GetMapping("/getAllProductsByWord/{word}")
	public List<Product> getAllProductsByWord(@PathVariable("word") String word) {
		return service.getAllProductsLike(word);
	}

}
