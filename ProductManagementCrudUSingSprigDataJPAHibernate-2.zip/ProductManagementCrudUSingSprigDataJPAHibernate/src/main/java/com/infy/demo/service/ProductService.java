package com.infy.demo.service;

import java.util.List;
import java.util.Optional;

import com.infy.demo.model.Product;

public interface ProductService {
	public Product addProduct(Product product);

	public Product updateProduct(Product product);

	public String deleteProduct(int productId);

	public Optional<Product> getProduct(int productId);

	public List<Product> getAllProducts();

	public List<Product> getAllProductsByName(String productName);

	public List<Product> getAllProductsByCategory(String productCategory);

	public List<Product> getAllProductsByBetweenPrices(int iPrice, int price);

	public List<Product> getAllProductsLike(String word);// sam

}
