package com.infy.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;


@Entity
@Table(name = "products")
public class Product {
	@Id
	@Column(name = "pid")
	@Max(value = 100,message = "productid must be below 100...")
	private int productId;
	@Column(name = "pname", length = 15)
	@NotNull
	@Pattern(regexp="[A-Za-z]+( [A-Za-z]+)*", message="Name should contain only alphabets and space")
	private String productName;
	@Column(name = "price")
	@Min(value = 100,message="price must be above 100..")
	private int productPrice;
	@Column(name = "category", length = 15)
	private String productCategory;
	@Column(name = "quantity")
	private int productQuantity;
	@Column(name = "description", length = 15)
	private String productDescription;
	@Column(name = "soldby", length = 15)
	private String productSoldBy;

	public Product() {

	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productPrice=" + productPrice
				+ ", productCategory=" + productCategory + ", productQuantity=" + productQuantity
				+ ", productDescription=" + productDescription + ", productSoldBy=" + productSoldBy + "]";
	}

	public Product(int productId, String productName, int productPrice, String productCategory, int productQuantity,
			String productDescription, String productSoldBy) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productCategory = productCategory;
		this.productQuantity = productQuantity;
		this.productDescription = productDescription;
		this.productSoldBy = productSoldBy;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public int getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public String getProductSoldBy() {
		return productSoldBy;
	}

	public void setProductSoldBy(String productSoldBy) {
		this.productSoldBy = productSoldBy;
	}

}
