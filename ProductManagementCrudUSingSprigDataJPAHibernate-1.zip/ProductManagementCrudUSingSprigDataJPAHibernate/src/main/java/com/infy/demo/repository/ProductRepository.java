package com.infy.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infy.demo.model.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> {
	// @Query("select e from Product e where e.productName=?1")
	List<Product> findByProductName(String productName);

	// @Query("select e from Product e where e.productCategory=?1")
	List<Product> findByProductCategory(String productCategory);

	// @Query(select e from Product e where e.productPrice between ?1 and ?2)
	List<Product> findByProductPriceBetween(int price1, int price2);

	List<Product> findByProductNameContaining(String word);
}
