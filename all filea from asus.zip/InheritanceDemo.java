class A{
    void m1(){System.out.println("In the m1 method of A class");}
}
class B extends A{
    void m2(){super.m1();System.out.println("In the m2 method of B class");}
}
class C extends B{
    void m3(){super.m2();System.out.println("In the m3 method of C class");}
}
public class InheritanceDemo{
     public static void main(String [] args){
        C c1 = new C();
        c1.m3();    
   }
}