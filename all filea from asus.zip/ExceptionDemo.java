//user defined exceptions
class AgeInvalidException extends Exception{
   String message;
   AgeInvalidException(String message){this.message=message;}  

}
class Employee{
    int id;
    String name;
    int age; 
    
    Employee(){}
    
    void setId(int id){this.id=id;}
    void setName(String name){this.name=name;}
    void setAge(int age) throws AgeInvalidException{
          if(age<18)
              throw new AgeInvalidException("the employees in infosys are greater than 18 years of age");
          else  
              this.age=age;
    }
    
    void  displayEmployee(){
         System.out.println("the id of the employee is "+this.id);
         System.out.println("the name of the employee is "+this.name);
         System.out.println("the age of the employee is "+this.age);
    }
}
public  class ExceptionDemo{
     public static void main(String [] args){
          Employee e1 = new Employee();
          e1.setId(2);
          e1.setName("nikhil");
          try{
             e1.setAge(3);
          }catch(AgeInvalidException ex){
               System.out.println(ex.message); 
          } 
          e1.displayEmployee(); 

     }
}