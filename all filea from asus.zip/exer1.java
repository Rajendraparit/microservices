import java.util.Scanner;

public class exer1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		System.out.println("Input number");
		int input = in.nextInt();
		if (input > 0) {
			System.out.println("Number is positive");
		} else {
			System.out.println("Number is negative");
		}
	}

}
