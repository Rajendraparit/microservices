import  java.util.Scanner;
public class WrapperDemo{
     public static void main(String [] args){
          Scanner sc = new Scanner(System.in);
          System.out.println("please enter your first number");
          int a=sc.nextInt(); 
          System.out.println("please enter your second number");
          int b=sc.nextInt();
           
          System.out.println("the sum of "+a+" and "+b+"  is  "+(a+b));          
    }
}




