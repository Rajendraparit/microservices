import  java.util.Scanner;
public class WrapperDemo{
     public static void main(String [] args){
          String str1="12";
          String str2="13";
 
          System.out.println(Integer.parseInt(str1)+Integer.parseInt(str2));          
    }
}