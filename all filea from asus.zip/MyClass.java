package arpitaapplication;
import java.util.*;

public class MyClass{
    public static void main(String[] args) {
        List<String> friends= new ArrayList<String>();
        friends.add("gagan");
        friends.add("jayant");
        friends.add("nandan");
        friends.add("manish");
        
        System.out.println(friends.get(0));
        //print the arraylist
        
        System.out.println("the size of the array list is  "+friends.size());
        for(int i=0;i<friends.size();i++)
            System.out.print(friends.get(i)+"   ");
        
        System.out.println("\n========================================\n");
        
        for(String s:friends)
            System.out.print(s+"   ");
        
    }
}