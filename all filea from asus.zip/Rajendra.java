class Raju
	{
		public static void main(String [] args);
		System.out.println("Hello Rajendra")



}



//yes @rajendra.parit unimplemented methods of the parent abstract class are overrriden in the derived class


abstract class Shape{
    abstract void draw();
}
class Square extends Shape{
     void draw(){
          System.out.println("drawing a square"); 
    }    
}
class Rectangle extends Shape{
     void draw(){
          System.out.println("drawing a rectangle"); 
    }    
}
class Circle extends Shape{
     void draw(){
          System.out.println("drawing a circle"); 
    }    
}
public class AbstractDemo{
     public static void main(String [] args){
           
           
     }
}










import java.util.Date;
abstract class Hello {
    public void printTime() {
        System.out.println("Today's time : " + new Date().getHours());
    }
    public abstract void sayHello();
}
public class AbstractionTest extends Hello {
    public void printDate() {
        System.out.println("Today's Date : " + new Date());
    }
    public static void main(String[] args) {
        AbstractionTest obj = new AbstractionTest();
        obj.printDate();
        obj.printTime();
        obj.sayHello();
    }
    public void sayHello() {
        System.out.println("time for BF");
    }
}






package com.infosys.oops;
import java.util.Date;
interface A
{
    }
interface ParentI extends A {
    // by default interface methods are public abstract
    // by default interface variables public static final
     int marks=0;//public static final
    public abstract void m1();
    void m2();
    
}
abstract class Hello implements  ParentI {
    public void printTime() {
        System.out.println("Today's time : " + new Date().getHours());
    }
    public  void m1() {
        System.out.println("am from Hello class m1");
    }
    public abstract void sayHello();
}
public class AbstractionTest extends Hello {
    public void printDate() {
        System.out.println("Today's Date : " + new Date());
    }
    public static void main(String[] args) {
        AbstractionTest obj = new AbstractionTest();
        obj.printDate();
        obj.printTime();
        obj.sayHello();
    }
    public void sayHello() {
        System.out.println("time for BF");
    }
    
    @Override
    public void m2() {
        
    }
}







//whenever we create  an object of a class constructor is called
//if there is no constructor in the class the compiler will insert a default no-arg constructor
class Student{
    int id;
    String name;
    int age;
  
    Student(){
        System.out.println("Inside the student class 0 arg constructor");
    }
    Student(int i , String n , int a){
        System.out.println("Inside the student class 3 arg constructor");
        id=i;
        name=n;
        age=a;
    }
   void displayStudent(){
      System.out.println("the id is "+id);
      System.out.println("the name is "+name);
      System.out.println("the age is "+age);
   }
}
public class StudentDemo{
     public static void main(String [] args){
         Student s1 = new Student();
         Student s2 = new Student(12 , "nitin" , 22);
 
     }
}
























