import java.util.Scanner;
public class SimpleInterest{
     
     static double calculateSI(double amount , int rate , int time){
          return (amount*rate*time)/100;
     }
    
     public static void main(String [] args){
         Scanner sc = new Scanner(System.in);
         System.out.println("please enter the amount");
         double amount=Double.parseDouble(sc.nextLine());        
         System.out.println("please enter the rate of interest");
         int rate=Integer.parseInt(sc.nextLine());
         System.out.println("please enter the time");
         int time=Integer.parseInt(sc.nextLine());
         double si=SimpleInterest.calculateSI(amount , rate , time);
         System.out.println("your SI is "+si); 
    }
}